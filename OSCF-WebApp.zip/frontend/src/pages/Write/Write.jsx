import { useContext,useState } from "react";
import axios from "axios";
import UserContext from "../../context/createcontext";
export default function Write(){
    const [title,setTitle]=useState("");
    const [description,setDescription]=useState("");
    const [keyword,setKeyord]=useState("");
    const [photo,setPhoto]=useState("");

    const handleSubmit=async(e)=>{
        e.preventDefault();
        const newBlog={
            title,
            description,
        };
        if(photo)
        {
            const data=new FormData();
            const filename=Date.now()+photo.name;
            data.append("name",filename);
            data.append("photo",photo);
            newBlog.photo=filename;
            try{
                await axios.post("/upload",data);

            }catch(err){}
        }
        try{
            const res=await axios.post("http://localhost:8080/blogs/cblog",newBlog);

        }catch(err){}
    };
    return(
        <div>
          <form onSubmit={handleSubmit} >
          <div>
          <input
            type="text"
            placeholder="Title"
            
            autoFocus={true}
            onChange={e=>setTitle(e.target.value)}
          />
        </div>
        <div className="writeFormGroup">
          <textarea
            placeholder="Tell your story..."
            type="text"
            
            onChange={e=>setDescription(e.target.value)}
          ></textarea>
        </div>
        <button  type="submit">
          Publish
        </button>
            </form> 
        </div>
    )
}