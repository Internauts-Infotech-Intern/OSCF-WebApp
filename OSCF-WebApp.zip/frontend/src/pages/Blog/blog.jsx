import { useEffect,useState } from "react";
import axios from "axios";

import { useLocation,Link } from "react-router-dom";

export default function Blog(){
    const [blog,setBlog]=useState([]);
    
    useEffect(()=>{
        const fetchBlogs=async()=>{
            const res=await axios.get("http://localhost:8080/blogs/blog");
            console.log(res.data);
            setBlog(res.data);
            
        };
        fetchBlogs();
        
    },[]);
    return(
        <div>
            {blog.map((p)=>(
                <div key={p._id}>
                
                <Link to={`/blog/${p._id}`}>
                    <span >{p.title}</span>
                </Link>
                <hr></hr>
                <p>{p.description}</p>
                
            </div>
            ))}
        </div>
    )
}