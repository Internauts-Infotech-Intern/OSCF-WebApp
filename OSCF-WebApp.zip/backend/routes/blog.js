const router = require("express").Router();
const Blog = require("../models/Blog");
//Get All Post
router.get("/blog", async (req, res) => {
    try {
        console.log("Entered in blog retrive page")
        let blog;
        blog = await Blog.find();

        console.log("BLog retrival finished",blog);
        
        res.send(blog);
    } catch (err) {
        res.status(500).json(err);
    }
});
//Create Post
router.post("/cblog", async (req, res) => {
    const newBlog = new Blog(req.body);
    try {
        const savedBlog = await newBlog.save();
        res.status(200).json(savedBlog);
    }
    catch (err) {
        res.status(500).json(err);
    }
})
//Update Post
router.put("/:id", async (req, res) => {
    try {
        console.log("This method is called")
        const blog = await Blog.findById(req.params.id);
        console.log("Phase 1")
        
            try {
                const updateBlog = await Blog.updateOne(
                    {_id:req.params.id},
                    {
                        $set: req.body,
                    },
                    { new: true }
                )
                console.log("Phase 2")
                res.status(200).json(updateBlog)
            } catch (err) {
                res.status(500).json(err);
            }
        
    } catch (err) {
        res.status(500).json(err);
    }
});

//GET Blog
router.get("/:id", async (req, res) => {
    try {
      const blog = await Blog.findById(req.params.id);
      console.log(blog);
      res.status(200).json(blog);
    } catch (err) {
      res.status(500).json(err);
    }
  });
  

//Delete Post
router.delete("/:id", async (req, res) => {
    try {
        console.log("Entered at stage 1")

      const blog = await Blog.findById(req.params.id);
      console.log("Entered at stage 2")
          try{
            console.log(blog);
            await blog.deleteOne();
          console.log("Entered at stage 3")
          res.status(200).json("Blog has been deleted...");}
        catch(err){
            res.status(500).json(err);
        }
      
    } catch (err) {
      res.status(500).json(err);
    }
  });
module.exports = router;